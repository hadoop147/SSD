puts"Lets check to see if you are any richer"
netWorth=1000
puts"Did you sell something?\n1=Yes\n2=No"
answer=gets
if answer.to_i==1
    puts"How much did you sell?"
    amt=gets
    newNetWorth=netWorth+amt.to_i
    puts"Earlier your worth was: #{netWorth}\nYou are now worth: #{newNetWorth}"
elsif answer.to_i==2
    puts"Not too worry, better luck next time"
end