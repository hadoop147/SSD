puts "Enter No 1"
num1 = gets
puts "Enter No 2"
num2 = gets
puts num1.to_i * num2.to_i