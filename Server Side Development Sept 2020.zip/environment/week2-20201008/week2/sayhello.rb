puts "Hi what is your name?"
name = gets
puts "Welcome #{name}"