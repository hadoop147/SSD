puts "welcome to finding how much you are worth did you sell anything \n 1 = no\n 2 = yes"

worth = 666000 # sets the initial worth of the person

answer = gets # set the persons choice so we can use it later 

if answer.to_i == 1 ## convert the input to int snd compare it to 1 
puts "hard luck you still have " + worth.to_s


elsif answer.to_i == 2
puts "how much did you sell"
amt = gets
nweworth = worth.to_i + amt.to_i 
puts "You are now worth " + nweworth.to_s
end

