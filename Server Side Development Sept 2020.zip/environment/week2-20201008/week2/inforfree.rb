class Zoo
    attr_accessor :name, :age, :allowed # declaring my attributes
    
    def initialize(name, age, location)
    # take in the names of what I need to make this work 
    @name = name
    @age = age
    @location = location
    
    @allowed = get_person_type
    end
    
    # the next method is going to determine if the person has to pay
    def get_person_type
        if (@age > 24)
            return "The person #{name} who is #{age} can get in for free"
        # run a check on the age and output the required result
        end
        return "you are too young so you must pay €55"
    end
    
    private :get_person_type
    
    
end

person = Zoo.new('Liam', 39, "Navan")
puts person.allowed