puts "What is your name?"
name = gets
puts "Hello #{name}"

