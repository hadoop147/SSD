puts"Show me the total including VAT"
puts"How much was the original value?"
amt=gets.to_i
total=amt*1.23
puts "The Total due is #{total}"