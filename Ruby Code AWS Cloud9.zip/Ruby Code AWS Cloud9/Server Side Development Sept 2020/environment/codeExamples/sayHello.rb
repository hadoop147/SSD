puts "What is your name?"
username=gets.chomp
puts "#{username} is cool, he is a gamer head"