puts "What number would you like"
user=gets.chomp
if user=="Rory"
    2.times{puts"Welcome #{user}"}
else 
    2.times{puts"Where is #{user}?"}
end