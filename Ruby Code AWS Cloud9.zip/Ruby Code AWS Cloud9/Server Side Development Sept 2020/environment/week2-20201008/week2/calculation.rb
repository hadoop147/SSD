puts "What is the value you want to calculate?"
amt = gets.to_i
total = amt * 1.21
puts "The total is #{total}"